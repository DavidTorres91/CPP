#include <iostream>

using namespace std;

int main()
{
	
	//Declaro variables globales

	int base, altura, area;

	
	
    cout<<"Calculador de Area de un Rectangulo"<<endl;
    
    cout<<"Digite Base del Rectangulo."<<endl;cin>>base;
	cout<<"Digite la Altura del Rectangulo"<<endl;cin>>altura;
	area = base*altura;
    system("cls");
	
    cout<<"Calculador de Area de un Rectangulo"<<endl;		
	
	cout<<"El area de un Rectangulo de Base " << base <<" y Altura " << altura << " es: "<<endl;
    cout<< area <<endl;
    cout<<"Gracias por usar Calculadora de area Rectangulo"<<endl;


    
    //Anibal David Paname�o
    
    

    return 0;
}

