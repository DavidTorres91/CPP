#include <iostream>

using namespace std;

int main()
{
	
	//Declaro variables globales

	int radio ;

	double pi=3.14,area;
	
    cout<<"Calculador de Area de un Circulo"<<endl;
    
    cout<<"Digite el Radio del Circulo."<<endl;cin>>radio;
	area = radio*pi;
    system("cls");
	
    cout<<"Calculador de Area de un Circulo"<<endl;		
	
	cout<<"El Area de un Circulo de Radio es:  " <<endl;
    cout<< area <<endl;
    cout<<"Gracias por usar Calculadora de area Circulo"<<endl;


    
    //Anibal David Paname�o
    
    

    return 0;
}

