#include <iostream>

using namespace std;

int main()
{
	
	//Declaro variables globales

	int base, altura, area;

	
	
    cout<<"Calculador de Area de un Triangulo"<<endl;
    
    cout<<"Digite Base del Triangulo."<<endl;cin>>base;
	cout<<"Digite la Altura del Triangulo"<<endl;cin>>altura;
	area = (base*altura)/2;
    system("cls");
	
    cout<<"Calculador de Area de un Triangulo"<<endl;		
	
	cout<<"El area de un Triangulo de Base " << base <<" y Altura " << altura << " es: "<<endl;
    cout<< area <<endl;
    cout<<"Gracias por usar Calculadora de area Triangulo"<<endl;


    
    //Anibal David Paname�o
    
    

    return 0;
}

