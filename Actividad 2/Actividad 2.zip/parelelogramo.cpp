#include <iostream>

using namespace std;

int main()
{
	
	//Declaro variables globales

	int base, altura, area;

	
	
    cout<<"Calculador de Area de un Parelelogramo"<<endl;
    
    cout<<"Digite Base del Parelelogramo."<<endl;cin>>base;
	cout<<"Digite la Altura del Parelelogramo"<<endl;cin>>altura;
	area = base*altura;
    system("cls");
	
    cout<<"Calculador de Area de un Parelelogramo"<<endl;		
	
	cout<<"El area de un Parelelogramo de Base " << base <<" y Altura " << altura << " es: "<<endl;
    cout<< area <<endl;
    cout<<"Gracias por usar Calculadora de area Parelelogramo"<<endl;


    
    //Anibal David Paname�o
    
    

    return 0;
}

